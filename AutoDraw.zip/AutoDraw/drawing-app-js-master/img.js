function func() {
    var img = document.getElementById("mno");
    var canv = document.getElementById("myCanvas");
    var ctx = canv.getContext("2d");
    ctx.drawImage(img, 0, 0, 50, 50);
}
